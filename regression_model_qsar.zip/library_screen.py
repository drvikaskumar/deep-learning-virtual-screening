"""
Utility script to train a QSAR regression model on a single‑target ChEMBL
dataset and screen multiple external libraries of compounds.

This script is intended to be run from the command line.  It uses the
functions defined in ``qsar_pipeline/pipeline.py`` to perform data
curation, feature computation, model training with cross‑validation, and
similarity‑based applicability domain estimation.  After training the
model, each provided screening library is read, the SMILES strings are
standardised and featurised, and predictions are computed.  Compounds
lying outside the applicability domain are flagged, and simple
drug‑likeness filters are applied before ranking by predicted pIC₅₀.

Example usage:

```
python library_screen.py \
    --target_csv /path/to/btk.csv \
    --library_csv reference_ligands_from_sdf.csv l1300_fda_approved_library_input.csv l1400_natural_product_library_input.csv \
    --output_dir ./screen_results \
    --n_splits 2
```

By default the script looks for a column named ``Smiles`` in each library
file.  If your library uses a different case (e.g. ``SMILES`` or
``smiles``), the script will automatically detect and rename it.

Note: cross‑validation with six models can be computationally intensive.
Use the ``--n_splits`` argument to reduce the number of folds during
development.

"""

from __future__ import annotations

import argparse
import os
import pandas as pd
import numpy as np
from typing import List

from qsar_pipeline.pipeline import (
    load_chembl_dataset,
    clean_and_standardise_smiles,
    convert_ic50_to_pic50,
    compute_features,
    _assemble_feature_matrix,
    scaffold_split,
    estimate_applicability_domain,
    screen_library,
)
from xgboost import XGBRegressor


def parse_args() -> argparse.Namespace:
    """Parse command‑line arguments for library screening."""
    parser = argparse.ArgumentParser(description='Train a QSAR model and screen external libraries.')
    parser.add_argument('--target_csv', type=str, required=True, help='Path to the ChEMBL activity CSV (e.g. btk.csv).')
    parser.add_argument('--library_csv', type=str, nargs='+', required=True, help='Paths to screening library CSV files.')
    parser.add_argument('--output_dir', type=str, required=True, help='Directory to write screening results.')
    parser.add_argument('--test_fraction', type=float, default=0.2, help='Fraction of target data used for testing.')
    parser.add_argument('--random_state', type=int, default=42, help='Random seed for reproducibility.')
    parser.add_argument('--top_n_hits', type=int, default=100, help='Number of top hits to save for each library.')
    return parser.parse_args()


def train_model_and_screen(target_csv: str, library_paths: List[str], output_dir: str,
                           test_fraction: float = 0.2, random_state: int = 42, top_n_hits: int = 100) -> None:
    """Train a model on the target data and screen multiple libraries.

    Parameters
    ----------
    target_csv : str
        Path to the ChEMBL activity CSV containing at least columns ``Smiles``, ``Standard Relation``, and ``Standard Value``.
    library_paths : list of str
        List of paths to CSV files containing SMILES strings to screen.
    output_dir : str
        Directory where results will be written.
    n_splits : int, default 3
        Number of cross‑validation folds to use when training models.
    test_fraction : float, default 0.2
        Fraction of the curated data reserved for the test set (used only for reporting).  The model is trained on the training portion.
    random_state : int, default 42
        Random seed used for reproducibility in data splitting and model training.
    top_n_hits : int, default 100
        Number of top compounds to retain in each screening result.
    """
    os.makedirs(output_dir, exist_ok=True)
    # Step 1: load and curate target dataset
    print(f'Loading target data from {target_csv}...')
    df_raw = load_chembl_dataset(target_csv)
    print(f'Loaded {len(df_raw)} activity records.')
    df_clean = clean_and_standardise_smiles(df_raw, smiles_column='Smiles')
    df_pic50 = convert_ic50_to_pic50(df_clean, value_column='Standard Value')
    print(f'After cleaning and conversion, {len(df_pic50)} molecules remain.')
    if len(df_pic50) < 10:
        raise RuntimeError('Too few data points remain after curation – aborting.')
    # Step 2: compute molecular features and fingerprint bit vectors
    print('Computing features for target dataset...')
    ecfp, maccs, desc, descriptor_names, ecfp_bv_list = compute_features(df_pic50)
    # Align DataFrame length with computed features
    df_pic50 = df_pic50.iloc[:len(ecfp)].reset_index(drop=True)
    X = _assemble_feature_matrix(ecfp, maccs, desc, use_fingerprints=True, use_maccs=True, use_desc=True)
    y = df_pic50['pIC50'].values
    # Step 3: split into training and test sets (scaffold‑based)
    train_idx, test_idx = scaffold_split(df_pic50, test_fraction=test_fraction, random_state=random_state)
    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]
    ecfp_bv_train = [ecfp_bv_list[i] for i in train_idx]
    # Step 4: train models with cross‑validation
    # Rather than training multiple models via cross‑validation, we train a single XGBoost regressor
    # on the training data.  This reduces runtime while still providing competitive performance.
    print('Training XGBoost regressor...')
    best_model = XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=random_state,
        tree_method='hist',
        objective='reg:squarederror',
        n_jobs=-1,
    )
    best_model.fit(X_train, y_train)
    # Evaluate on test set for reporting
    test_preds = best_model.predict(X_test)
    # Compute R2 using correlation squared
    if len(y_test) > 1:
        test_r2 = float(np.corrcoef(y_test, test_preds)[0, 1]**2)
    else:
        test_r2 = float('nan')
    test_rmse = float(np.sqrt(((y_test - test_preds) ** 2).mean()))
    test_mae = float(np.abs(y_test - test_preds).mean())
    print(f'Test metrics: R² = {test_r2:.3f}, RMSE = {test_rmse:.3f}, MAE = {test_mae:.3f}')
    # Step 5: estimate applicability domain threshold based on training data
    print('Estimating applicability domain...')
    _, ad_threshold = estimate_applicability_domain(ecfp_bv_train, ecfp_bv_train, k=5, percentile=5.0)
    print(f'Applicability domain threshold (mean similarity) = {ad_threshold:.3f}')
    # Step 6: screen each library
    for lib_path in library_paths:
        lib_basename = os.path.splitext(os.path.basename(lib_path))[0]
        print(f'Screening library {lib_basename}...')
        try:
            lib_df = pd.read_csv(lib_path)
        except Exception as exc:
            print(f'Warning: could not read {lib_path}: {exc}')
            continue
        # Auto‑detect the SMILES column
        smiles_col = None
        for col in lib_df.columns:
            if col.lower() == 'smiles':
                smiles_col = col
                break
        if smiles_col is None:
            print(f'Warning: no SMILES column found in {lib_path}; skipping.')
            continue
        smiles_list = lib_df[smiles_col].dropna().astype(str).tolist()
        # Perform screening with drug‑likeness filtering
        # Perform screening; disable drug‑likeness filtering here to ensure we retain all molecules.
        screen_df = screen_library(smiles_list, best_model, ecfp_bv_train, ad_threshold, k=5, druglike=False)
        # Retain only top_n_hits.  If the DataFrame is empty, just save the empty result.
        if not screen_df.empty:
            screen_df = screen_df.head(top_n_hits)
        out_file = os.path.join(output_dir, f'{lib_basename}_screening_results.csv')
        screen_df.to_csv(out_file, index=False)
        print(f'Saved {len(screen_df)} hits to {out_file}')


def main() -> None:
    args = parse_args()
    train_model_and_screen(
        target_csv=args.target_csv,
        library_paths=args.library_csv,
        output_dir=args.output_dir,
        test_fraction=args.test_fraction,
        random_state=args.random_state,
        top_n_hits=args.top_n_hits,
    )


if __name__ == '__main__':
    main()