# QSAR Pipeline for Single-Target Regression

This repository provides a set of Python scripts that implement a complete QSAR (Quantitative Structure–Activity Relationship) pipeline for building and validating regression models on a single ChEMBL target.  The pipeline is designed to follow best practices described in the scientific literature, including rigorous data curation, multiple molecular representations, cross‑validated model training, applicability domain analysis and explainability.  It culminates in a virtual screening module that can prioritise compounds from an external library.

The provided scripts are intentionally written as plain Python files so that they can be executed in a command‐line environment, a Jupyter notebook or from within an IDE such as VS Code.  Each script contains high‑level functions that encapsulate the individual steps of the workflow, making it easy for newcomers to understand and adapt.

## Contents

* `pipeline.py` – core implementation of the QSAR workflow.  Defines functions for loading and cleaning the dataset, computing molecular features, training multiple regression models, assessing model performance, estimating an applicability domain, generating SHAP explanations and performing virtual screening.
* `run_pipeline.py` – example entry point that demonstrates how to invoke the functions in `pipeline.py` on the provided BTK (Bruton’s Tyrosine Kinase) dataset.  It performs the complete workflow end‑to‑end and writes results to CSV files in the `results` directory.

## Installation

The scripts rely on a handful of common scientific Python libraries.  RDKit is used for molecular processing, scikit‑learn and several gradient boosting libraries are used for model training, and SHAP is used for interpretability.  All of these are pre‑installed in the execution environment used to develop these scripts.  If you are running this pipeline locally, ensure that the following packages are available:

```bash
pip install pandas numpy scikit-learn rdkit-pypi xgboost lightgbm catboost shap
```

No internet connection is required for the pipeline once the dependencies are installed.

## Usage

1. **Prepare your dataset.**  Make sure your ChEMBL‑derived CSV file includes a `Smiles` column containing canonical SMILES strings, a `Standard Value` column containing activity data (e.g. IC50 values expressed in nanomolar units) and associated metadata.  The supplied `btk.csv` file fulfils these requirements.

2. **Run the example script.**  From a terminal in this directory, execute:

```bash
python run_pipeline.py --input_csv /path/to/btk.csv --output_dir ./results
```

This will perform data curation, compute ECFP4 fingerprints, MACCS keys and a set of physicochemical descriptors, split the data into training and test sets, train several regression models (Random Forest, XGBoost, LightGBM, CatBoost, Support Vector Regression and a Multi‑Layer Perceptron), perform 5‑fold cross‑validation, estimate an applicability domain, compute SHAP values for the top model and write summary results.  Predictions for the external test set and virtual screening (if a library file is provided) are also saved.

3. **Screen an external library (optional).**  To prioritise compounds from a chemical library, supply a CSV file containing a column named `Smiles` via the `--screen_csv` argument:

```bash
python run_pipeline.py --input_csv /path/to/btk.csv --screen_csv /path/to/library.csv --output_dir ./results
```

The script will compute the same descriptors for the library, filter compounds to ensure they are within the applicability domain of the model, rank them by the consensus predicted pIC50 and apply simple drug‑likeness filters (molecular weight, logP, hydrogen bond donors/acceptors, rotatable bonds) before writing the top hits to `screening_results.csv`.

## Pipeline Overview

The workflow implemented here follows recommendations from the cheminformatics literature:

1. **Data curation.**  Only records with IC50 values, exact relationships (`=`) and nanomolar units are retained.  Molecules are standardised by removing salts and mixtures, choosing the largest organic fragment, sanitising the structure and generating a canonical SMILES.  Inorganics and records lacking carbon atoms are discarded.  Duplicates are removed.  These steps mirror best practice guidelines for chemical data curation【962878708436635†L160-L167】.

2. **Unit conversion.**  IC50 values (in nM) are converted to pIC50 using the formula `pIC50 = 9 – log10(IC50_nM)`.  This transformation yields a logarithmic potency scale analogous to pH, making data easier to interpret【171224809600439†L189-L197】.

3. **Molecular featurisation.**  Three complementary representations are computed:
   * **ECFP4 fingerprints** – 2048‑bit extended connectivity fingerprints (radius 2).  These have been shown to provide robust and informative descriptors for QSAR modelling【851742792911846†L1090-L1104】 and strike a balance between resolution and efficiency【851742792911846†L1102-L1104】.
   * **MACCS keys** – 166‑bit key‑based fingerprints.  Binary fingerprints such as the 166‑bit MACCS keys are widely used because they are fast to compute and enable rapid similarity calculations【186599205751167†L229-L233】.
   * **Physicochemical descriptors** – a small set of interpretable RDKit descriptors (molecular weight, logP, topological polar surface area, hydrogen‑bond donors/acceptors, rotatable bonds, ring count, fraction of sp³ carbon, etc.).  These features provide additional global information about the molecules.

4. **Model training and evaluation.**  The curated dataset is split into training and test sets using a scaffold‑based split (via the Bemis–Murcko scaffold) to reduce structural overlap between sets.  Six regression algorithms are benchmarked using 5‑fold cross‑validation: Random Forest, XGBoost, LightGBM, CatBoost, Support Vector Regression and a simple Multi‑Layer Perceptron.  Performance metrics (R², RMSE, MAE) are reported.  An ensemble prediction can optionally be obtained by averaging the top models.

5. **Applicability domain.**  A similarity‑based applicability domain is estimated using k‑nearest neighbours on ECFP4 fingerprints.  For each compound, the mean Tanimoto similarity to its five nearest neighbours in the training set is computed; compounds below the 5th percentile of the training similarity distribution are considered outside the domain, following the procedure described by Morales‑Ortiz et al. 【851742792911846†L1189-L1203】.  Screening predictions falling outside the applicability domain are flagged.

6. **Explainability.**  SHAP (SHapley Additive exPlanations) values are calculated for the best performing model to identify which fingerprint bits and descriptors contribute most to the predicted pIC50.  SHAP provides a game‑theoretic framework for interpreting complex models【851742792911846†L1215-L1220】.

7. **Virtual screening (optional).**  When a library file is provided, the pipeline computes the same descriptors, filters compounds that lie within the applicability domain, predicts their pIC50 using the selected model and ranks them.  Simple drug‑likeness rules (e.g. Lipinski’s Rule of Five) are applied to remove undesirable chemotypes.  The top ranked hits are saved along with their predicted potency and property values.

## Further Customisation

The modular design of `pipeline.py` allows you to easily adapt the workflow to other targets, representations or modelling strategies.  You can alter the list of descriptors, tweak the hyperparameters of the regression algorithms, substitute alternative fingerprints (e.g. atom pair or topological torsion) or implement scaffold‑aware splitting strategies using tools like RDKit’s `ScaffoldSplitter`.

Feel free to experiment and extend these scripts to suit your specific research questions.  We hope this project serves as a clear and reproducible starting point for beginners entering the field of computational drug discovery.