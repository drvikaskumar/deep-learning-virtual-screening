# Regression Model QSAR

This repository contains a reproducible pipeline for building and evaluating
QSAR (Quantitative Structure–Activity Relationship) regression models
using ChEMBL bioactivity data.  The project demonstrates best
practices in cheminformatics for data curation, fingerprint and
descriptor generation, model training, evaluation, applicability domain
analysis, interpretation, and virtual screening.  It also includes
scripts for screening external chemical libraries and visualising
results.

## Contents

- **`qsar_pipeline/`** – Core pipeline implementation including data
  loading, cleaning, feature computation (ECFP4, MACCS, RDKit
  descriptors), scaffold splitting, model training/evaluation, AD
  estimation and SHAP explainability.
- **`library_screen.py`** – Script to train a model and screen external
  libraries using the full feature set (ECFP4 + MACCS + descriptors).
  It illustrates how to perform QSAR predictions and apply simple
  drug‑likeness filters.
- **`library_screen_custom.py`** – Alternative screening script that
  trains and predicts using only ECFP4 and MACCS fingerprints.  This
  variant avoids dropping molecules due to missing descriptors and is
  useful when screening large, diverse libraries.
- **`plot_results.py`** – Utility for generating plots such as the
  distribution of pIC₅₀ values, model performance across algorithms,
  and predicted vs. experimental scatter plots.
- **`custom_screen_results/`** – Results from screening three example
  libraries (reference ligands, FDA‑approved drugs, and natural
  products) using the ECFP+MACCS model.
- **`qsar_results/`** – Cross‑validation and test set results from
  training the ensemble QSAR models (full feature set).
- **Input data files** – `btk.csv` (ChEMBL bioactivity data for BTK
  inhibitors) and three screening libraries.

## Running the Pipeline

1. **Set up the environment.** Install Python ≥ 3.8 with the
   following packages: `pandas`, `numpy`, `rdkit`, `scikit‑learn`,
   `xgboost`, `lightgbm`, `catboost`, `seaborn`, `matplotlib`, and
   `shap`.
2. **Train and evaluate models.** Use `qsar_pipeline/run_pipeline.py`
   to load and curate your target dataset, compute features, split
   into training/test sets, train multiple models, estimate the
   applicability domain, compute SHAP values and, optionally, screen
   an external library.
   ```bash
   python qsar_pipeline/run_pipeline.py \
       --input_csv btk.csv \
       --output_dir qsar_results \
       --n_splits 5 \
       --random_state 42
   ```
3. **Screen external libraries.** To train a model and rank
   compounds in one or more screening libraries:
   ```bash
   python library_screen.py \
       --target_csv btk.csv \
       --library_csv reference_ligands_from_sdf.csv l1300_fda_approved_library_input.csv \
       --output_dir library_results \
       --top_n_hits 100
   ```
   For a version that uses only ECFP4 and MACCS fingerprints, which
   retains more molecules in diverse libraries, use
   `library_screen_custom.py`.
4. **Visualise results.** After training and/or screening, use
   `plot_results.py` to create summary plots.  For example:
   ```bash
   python plot_results.py \
       --training_csv btk.csv \
       --cross_val_csv qsar_results/cross_validation_results.csv \
       --test_preds_csv qsar_results/test_predictions.csv \
       --output_dir plots
   ```

## Notes

- **Data curation:** The pipeline removes salts, inorganic compounds and
  duplicates, standardises structures and converts IC₅₀ values to
  pIC₅₀.  These steps follow recommendations in the cheminformatics
  literature【962878708436635†L160-L167】【171224809600439†L189-L197】.
- **Feature engineering:** ECFP4 fingerprints (radius 2, 2048 bits)
  and MACCS keys (166 bits) are commonly used and provide a balance
  between expressiveness and efficiency【851742792911846†L1090-L1104】【186599205751167†L229-L233】.
  RDKit descriptors add physicochemical properties but may not be
  defined for some exotic structures, which is why the custom
  screening script omits them.
- **Applicability domain:** A k‑nearest neighbour similarity threshold
  ensures that predictions are made within the chemical space covered
  by the training set【851742792911846†L1189-L1203】.
- **Explainability:** SHAP values can be computed for tree‑based
  models to identify influential features and substructures.

Feel free to adapt the code for other targets, fingerprints or
machine‑learning algorithms.  Contributions and improvements are
welcome once the repository is shared publicly.